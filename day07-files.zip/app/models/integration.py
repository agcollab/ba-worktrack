"""Connections to JIRA / Azure DevOps (used from Day 21) and their value mappings."""
from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base
from app.models.mixins import TimestampMixin


class Integration(TimestampMixin, Base):
    __tablename__ = "integrations"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True)  # "Payments JIRA"
    kind: Mapped[str] = mapped_column(String(20))  # "jira" or "ado"
    base_url: Mapped[str] = mapped_column(String(255))
    remote_project: Mapped[str | None] = mapped_column(String(100))  # JIRA key / ADO project
    username: Mapped[str | None] = mapped_column(String(255))
    # The API token, encrypted with the cryptography library on Day 21. Never plain text.
    encrypted_token: Mapped[str | None] = mapped_column(Text)
    local_project_id: Mapped[int | None] = mapped_column(ForeignKey("projects.id", ondelete="SET NULL"))
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    last_sync_at: Mapped[datetime | None] = mapped_column(DateTime)

    mappings: Mapped[list["IntegrationMapping"]] = relationship(
        back_populates="integration", cascade="all, delete-orphan"
    )


class IntegrationMapping(Base):
    """Translates one value, e.g. our status "In Review" <-> JIRA status "Code Review"."""

    __tablename__ = "integration_mappings"
    __table_args__ = (UniqueConstraint("integration_id", "field", "local_value"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    integration_id: Mapped[int] = mapped_column(
        ForeignKey("integrations.id", ondelete="CASCADE"), index=True
    )
    field: Mapped[str] = mapped_column(String(30))  # "status", "priority", "task_type"
    local_value: Mapped[str] = mapped_column(String(50))
    remote_value: Mapped[str] = mapped_column(String(100))

    integration: Mapped[Integration] = relationship(back_populates="mappings")
