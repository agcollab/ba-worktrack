"""Database connection: engine, sessions, the Base class for models, and get_db().

Day 7 changes (compared with Day 6):
- Base now has a naming convention, so every constraint gets a predictable
  name. Alembic needs names to change constraints on SQLite later.
- SQLite foreign keys are switched on for every connection. SQLite ignores
  REFERENCES unless you ask (you saw this on Day 4 with PRAGMA foreign_keys).
"""
from collections.abc import Generator

from sqlalchemy import MetaData, create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.config import settings

# Pattern for constraint names, e.g. "fk_time_entries_task_id_tasks"
NAMING_CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    """Every model inherits from this. Base.metadata knows all the tables."""

    metadata = MetaData(naming_convention=NAMING_CONVENTION)


# check_same_thread=False: FastAPI may use the connection from another thread
engine = create_engine(
    settings.DATABASE_URL,
    connect_args={"check_same_thread": False} if settings.DATABASE_URL.startswith("sqlite") else {},
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


@event.listens_for(Engine, "connect")
def _enable_sqlite_foreign_keys(dbapi_connection, connection_record) -> None:
    """Run PRAGMA foreign_keys=ON each time a new SQLite connection opens."""
    if type(dbapi_connection).__module__.startswith("sqlite3"):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency: one session per request, always closed afterwards."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
