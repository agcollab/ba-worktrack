"""Shared test setup: a brand-new in-memory database for every test.

"sqlite://" (no file name) lives only in memory, so tests are fast and never
touch your real worktrack.db. StaticPool keeps one connection open, because
each new connection to an in-memory database would see an empty database.
"""
from collections.abc import Generator

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

import app.models  # noqa: F401  (registers every table on Base.metadata)
from app.database import Base


@pytest.fixture
def engine():
    test_engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(test_engine)  # build every table from the models
    yield test_engine
    test_engine.dispose()


@pytest.fixture
def db(engine) -> Generator[Session, None, None]:
    TestSession = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    with TestSession() as session:
        yield session
